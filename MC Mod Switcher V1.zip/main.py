import keyboard
import os
import data_func
data = data_func
import time
from colorama import Fore

import cursor

clear = lambda: os.system('cls')


def clamp(var, min, max):
    int = var
    if var > max:
        int = max
    if var < min:
        int = min
    return int

folderSelective = 0
openFolder = 0
def folderMenu():
    global folderSelective
    global openFolder
    if openFolder == 0:
        print(Fore.GREEN + "Hit 'enter' on folder to open directory")
        print(Fore.GREEN + "Hit 'backspace' when in directory to go back\n")
        list = ["Mods folders", "Minecraft directory folders"]
        for x in range(len(list)):
            if x == folderSelective:
                print(Fore.RED + list[x] + " -")
            else:
                print(Fore.WHITE + list[x])

        event = keyboard.read_event()
        if event.event_type == keyboard.KEY_DOWN and event.name == "w":
            folderSelective = folderSelective - 1
        if event.event_type == keyboard.KEY_DOWN and event.name == "s":
            folderSelective = folderSelective + 1
        folderSelective = clamp(folderSelective, 0, 1)

        if event.event_type == keyboard.KEY_DOWN and event.name == "enter":
            if folderSelective == 0:
                openFolder = 1
            if folderSelective == 1:
                openFolder = 2
    else:
        if openFolder == 1:
            modFolders()
        if openFolder == 2:
            listOfMinecraftFolders()

MFN = 0
def modFolders():
    global MFN
    global openFolder
    if MFN is None:
        MFN = 0

    list = data.readFile("modFolders", "path")
    print(Fore.GREEN + "Hit 'enter' on folder to enable to current mod folder")
    print(Fore.GREEN + "Hit 'd' on folder to delete selected folder")
    print(Fore.GREEN + "Yellow text means activated mod folder \n")
    for x in range(len(list)):
        if len(data.readFile("usedMod", "path")) == 1:
            item = data.readFile("usedMod", "path")
            item = str(item[0])[:-1]
            if list[x].replace("'", "").replace("[", "").replace("]", "")[:-1] == item:
                if x == MFN:
                    print((Fore.RED + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\") + " -"))
                else:
                    print((Fore.YELLOW + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\")))
            else:
                if x == MFN:
                    print((Fore.RED + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\") + " -"))
                else:
                    print((Fore.WHITE + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\")))
        else:
            if x == MFN:
                print((Fore.RED + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\") + " -"))
            else:
                print((Fore.WHITE + list[x].replace("'", "").replace("[", "").replace("]", "")[:-1].replace("#", "\\")))

    event = keyboard.read_event()
    if event.event_type == keyboard.KEY_DOWN and event.name == "w":
        MFN = MFN - 1
    if event.event_type == keyboard.KEY_DOWN and event.name == "s":
        MFN = MFN + 1
    MFN = clamp(MFN, 0, len(list) - 1)
    if event.event_type == keyboard.KEY_DOWN and event.name == "backspace":
        openFolder = 0

    if event.event_type == keyboard.KEY_DOWN and event.name == "d":
        itemToDelete = list[MFN][:-1]
        data.deleteCertainLine("modFolders", "path", itemToDelete)

    if event.event_type == keyboard.KEY_DOWN and event.name == "enter":
        if len(data.readFile("usedMod", "path")) == 0:
            data.addToHeading("usedMod", "path", list[MFN][:-1])

            path = str(data.readFile("MinecraftPath", "path")).replace("'", "").replace("[", "").replace("]", "")[:-2].replace("#", "\\")
            os.rename(path + "\\" + list[MFN][:-1], path + "\\" + "mods")
        else:
            item = data.readFile("usedMod", "path")
            item = str(item[0])[:-1]

            path = str(data.readFile("MinecraftPath", "path")).replace("'", "").replace("[", "").replace("]", "")[:-2].replace("#", "\\")
            os.rename(path + "\\" + "mods", path + "\\" + item)

            data.deleteCertainLine("usedMod", "path", item)
            data.addToHeading("usedMod", "path", list[MFN][:-1])
            os.rename(path + "\\" + list[MFN][:-1], path + "\\" + "mods")

# List of minecraft folders number
LOFN = 0
def listOfMinecraftFolders():
    global LOFN
    global openFolder
    if LOFN is None:
        LOFN = 0

    path = str(data.readFile("MinecraftPath", "path")).replace("'", "").replace("[", "").replace("]", "")[:-2].replace("#", "\\")
    list = os.listdir(path)
    revisedList = []
    for x in range(len(list)):
        if not os.path.isfile(path + "\\" + list[x]):
            revisedList.append(list[x])
    print(Fore.GREEN + "Hit enter on folder to add to mod folder \n")
    for x in range(len(revisedList)):
        if x == LOFN:
            print(Fore.RED + revisedList[x] + " -")
        else:
            print(Fore.WHITE + revisedList[x])

    event = keyboard.read_event()
    if event.event_type == keyboard.KEY_DOWN and event.name == "w":
        LOFN = LOFN - 1
    if event.event_type == keyboard.KEY_DOWN and event.name == "s":
        LOFN = LOFN + 1
    LOFN = clamp(LOFN, 0, len(revisedList) - 1)
    if event.event_type == keyboard.KEY_DOWN and event.name == "backspace":
        openFolder = 0

    if event.event_type == keyboard.KEY_DOWN and event.name == "enter":
        path = revisedList[LOFN]
        newPath = ""
        for x in range(len(path)):
            newPath = newPath + path[x]
        data.addToHeading("modFolders", "path", newPath)

while True:
    clear()
    cursor.hide()

    if data.checkFile("modFolders"):
        if data.doesHeadingExist("modFolders", "path") == False:
            data.addToFile("modFolders", "path", "a")
            data.deleteCertainLine("modFolders", "path", "a")
    else:
        data.addToFile("modFolders", "path", "a")
        data.deleteCertainLine("modFolders", "path", "a")

    if data.checkFile("usedMod"):
        if data.doesHeadingExist("usedMod", "path") == False:
            data.addToFile("usedMod", "path", "a")
            data.deleteCertainLine("usedMod", "path", "a")
    else:
        data.addToFile("usedMod", "path", "a")
        data.deleteCertainLine("usedMod", "path", "a")

    if data.checkFile("MinecraftPath"):
        if data.doesHeadingExist("MinecraftPath", "path"):
            folderMenu()
        else:
            path = input("Input file path to '.minecraft': \n")
            newPath = ""
            for x in range(len(path)):
                newPath = newPath + path[x]
            data.addToFile("MinecraftPath", "path", "a")
            data.addToHeading("MinecraftPath", "path", newPath)
            data.deleteCertainLine("MinecraftPath", "path", "a")
            print("Path stored!")
            time.sleep(5)
    else:
        path = input("Input file path to '.minecraft': \n")
        newPath = ""
        for x in range(len(path)):
            if path[x] == "\\":
                 newPath = newPath + "#"
            else:
                newPath = newPath + path[x]
        data.addToFile("MinecraftPath", "path", "a")
        data.addToHeading("MinecraftPath", "path", newPath)
        data.deleteCertainLine("MinecraftPath", "path", "a")
        print("File created and path stored!")
        time.sleep(5)
        folderMenu()