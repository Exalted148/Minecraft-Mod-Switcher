import pathlib
parentFileLocation = pathlib.Path(__file__).parent.resolve()
from os.path import exists

def addToFile(fileLocation, mainHeader, arguments):
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    f = open(finalFileLocation, "a")
    f.write(mainHeader + "{\n")
    for i in range(len(arguments)):
        argument = arguments[i]
        f.write(argument + '\n')
    f.write("}" + mainHeader + "\n")

def readFile(fileLocation, mainHeading):
    items = []
    global foundStart
    foundStart = "nothing"
    global foundEnd
    foundEnd = "nothing"
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    with open(finalFileLocation, "r") as f: 
        lines = f.readlines()
        for i in range(len(lines)):
            if mainHeading in lines[i]:
                if foundStart == "nothing":
                    foundStart = i + 1             
                else:
                    foundEnd = i
        
        distance = int(foundEnd) - int(foundStart)
        for i in range(distance):
            b = i + foundStart
            items.append(lines[b])

        return items

def readFileNumber(fileLocation, mainHeading):
    global foundStart
    foundStart = "nothing"
    global foundEnd
    foundEnd = "nothing"
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    with open(finalFileLocation, "r") as f: 
        lines = f.readlines()
        for i in range(len(lines)):
            if mainHeading in lines[i]:
                if foundStart == "nothing":
                    foundStart = i + 1             
                else:
                    foundEnd = i
        
        return foundStart, foundEnd + 1

def deleteLines(fileLocation, mainHeading):
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    if exists(finalFileLocation):
        foundHeading = False
        with open(finalFileLocation, "r") as f: 
            lines = f.readlines()
            for i in range(len(lines)):
                if mainHeading in lines[i]:
                    foundHeading = True
            if foundHeading:
                foundStart, foundEnd = readFileNumber(fileLocation, mainHeading)
                distance = foundEnd - foundStart
                for i in range(distance + 1):
                    if len(lines) >= foundStart:
                        del lines[foundStart - 1]

        with open(finalFileLocation, "w") as f:
                for i in range(len(lines)):
                    f.write(lines[i])
        return foundHeading

def deleteCertainLine(fileLocation, mainHeading, subHeadingDelete):
    items = readFile(fileLocation, mainHeading)
    for i in range(0, len(items)):
        messageToCut = items[i].replace("\n","")
        items[i] = messageToCut
    items.remove(subHeadingDelete)
    deleteLines(fileLocation, mainHeading)  
    addToFile(fileLocation, mainHeading, items)
    return items

def checkFile(fileLocation):
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    exist = exists(finalFileLocation)
    return exist

def doesHeadingExist(fileLocation, mainHeading):
    found = False
    finalFileLocation = str(parentFileLocation) + "/StoredFiles/" + fileLocation + ".txt"
    with open(finalFileLocation, "r") as f: 
        lines = f.readlines()
        for i in range(len(lines)):
            if mainHeading in lines[i]:
                found = True
    return found

def addToHeading(fileLocation, mainHeading, subHeading):
    items = []
    if doesHeadingExist(fileLocation, mainHeading) == True:
        items = readFile(fileLocation, mainHeading)
        for i in range(0, len(items)):
            messageToCut = items[i].replace("\n","")
            items[i] = messageToCut
        items.append(str(subHeading))
        deleteLines(fileLocation, mainHeading)
        addToFile(fileLocation, mainHeading, items)
    else:
        addToFile(fileLocation, mainHeading, [str(subHeading)])